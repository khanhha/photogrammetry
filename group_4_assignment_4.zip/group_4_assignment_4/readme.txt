hi, here is the source code of the assignment 4.
- please run the main file: lab_4.m to see the result.
- this file do the following things:
	+ estimate the fundamental matrix from the point correspondences in pnts_3.mat and pnts_4.mat. 
	+ calculate draw the epipolar lines on the two images.
	+ estimate the geometric error

